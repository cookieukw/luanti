The translation files in this directory intentionally include errors (which
would be reported when someone starts the devtest game in the de locale). This
allows the unittest to check that the translation file reader also handles
files that include errors.
