# Test ABMs

This mod contains a nodes and related ABM actions.
By placing these nodes, you can test basic ABM behaviours.

There are separate tests for ABM `chance`, `interval`, `min_y`, `max_y`, `neighbor` and `without_neighbor` fields.
